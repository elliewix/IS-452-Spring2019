def letter_grade(number_grade):
    if number_grade < 60:
        return 'F'
    elif number_grade <= 69:
        return 'D'
    elif number_grade <= 79:
        return 'C'
    elif number_grade <= 89:
        return 'B'
    elif number_grade <= 100:
        return 'A'
    else:
        return 'A+, I guess'


def main():
    grade = float(input('Number grade: '))
    print(letter_grade(grade))


main()
