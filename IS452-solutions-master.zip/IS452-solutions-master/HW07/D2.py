def silly(a, b, c):
    result = ''
    if a > b:
        if b > c:
            result += 'Spam Please!'
        else:
            result += "It's a late parrot!"
    elif b > c:
        result += 'Cheese Shoppe'
        if a >= c:
            result += 'Cheddar'
        elif a < b:
            result += 'Gouda'
        elif c == b:
            result += 'Swiss'
    else:
        result += 'Trees'
        if a == b:
            result += 'Chestnut'
        else:
            result += 'Larch'
    result += 'Done'
    return result


def main():
    print(silly(3, 4, 5))
    print(silly(3, 3, 3))
    print(silly(5, 4, 3))
    print(silly(3, 5, 2))
    print(silly(5, 4, 7))
    print(silly(3, 3, 2))


main()