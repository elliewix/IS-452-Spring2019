def class_standing(credits):
    if credits < 7:
        return 'Freshman'
    elif credits < 16:
        return 'Sophomore'
    elif credits < 26:
        return 'Junior'
    else:
        return 'Senior'


def main():
    class_credits = int(input('Number of credits: '))
    print(class_standing(class_credits))


main()