def fine(speed_limit, clocked_speed):
    if clocked_speed > speed_limit:
        speeding_amount = clocked_speed - speed_limit
        fine = 50 + 5 * speeding_amount
        if clocked_speed > 90:  # we are speeding (given above if statement) and also over 90
            fine += 200
        print('Fine:', fine)
    else:
        print('Speed is legal.')


def main():
    speed_limit = eval(input('Speed limit: '))
    clocked_speed = eval(input('Clocked speed: '))
    fine(speed_limit, clocked_speed)


main()