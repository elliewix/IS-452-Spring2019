def a(n):
    total = 0
    while n > 0:  # we'll go backwards! add the highest value (n), then reduce until we hit 1
        total += n  # add the current value of n
        n -= 1  # reduce the value of n by 1
    print(total)


def b(n):
    n = 2 * n - 1  # the nth odd number is equal to 2n-1, e.g. the 5th odd number is 2*5-1 = 9
    total = 0
    while n > 0:
        total += n
        n -= 2
    print(total)


def c():
    total = 0
    value = 0
    while value != 999:
        total += value
        value = float(input('Next number: '))
    print(total)


def d(n):
    number_of_times = 1
    while n // 2 != 1:
        n //= 2
        number_of_times += 1
    print(number_of_times)

