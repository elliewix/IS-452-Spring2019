# The purpose of this function is to read in only the parts of Dracula between the lines indicating the START and END of
# the Project Gutenberg Ebook. Though these lines aren't perfect indications of the main content of the book, they're
# close enough.
def get_text(dracula_file):
    start_of_book = '*** START OF THIS PROJECT GUTENBERG EBOOK DRACULA ***'
    end_of_book = '*** END OF THIS PROJECT GUTENBERG EBOOK DRACULA ***'

    dracula = open(dracula_file, 'r')

    line = dracula.readline()
    while line.strip() != start_of_book:
        line = dracula.readline()  # don't do anything, just read the next line
    line = dracula.readline()  # read one more line so we don't include the start text

    text = ''
    while line.strip() != end_of_book:
        text += line
        line = dracula.readline()

    dracula.close()  # close the file

    return text.strip()  # strip the whitespace from start and end of book


# The purpose of this function is to read and print however many lines the user wants from the Dracula file. If the user
# requests a negative number of lines, the function stops. This is an example of an interactive loop.
def get_lines_from(dracula_file):
    dracula = open(dracula_file, 'r')

    num_lines = 0  # start at 0 so that we don't read any lines initially
    while num_lines >= 0:
        for i in range(num_lines):  # this nested loop will call readline() however many times the user has requested
            print(dracula.readline().strip())

        try:  # we'll use try/except to ensure that the user input is an integer
            num_lines = int(input('NUMBER OF LINES, NEGATIVE NUMBER TO END: '))
        except ValueError:  # this error indicates that the input is not an integer
            print('PLEASE GIVE A WHOLE NUMBER...')
            num_lines = 0  # if we've previously asked for some lines and then hit this error, this lets the loop repeat without reading any extra lines incorrectly

    dracula.close()
