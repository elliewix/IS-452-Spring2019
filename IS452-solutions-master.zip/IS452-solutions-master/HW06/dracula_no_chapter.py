def main():
    # Open file and read lines
    file = open('dracula.txt', 'r')
    text = file.readlines()
    file.close()

    # Identify start and end of table of contents
    toc_start = text.index('CONTENTS\n')
    toc_end = text.index('DRACULA\n')

    # Slice out the full table of contents
    toc = text[toc_start:toc_end]

    # Iterate over lines, keeping only those that a) have text and b) don't start with 'CHAPTER'
    keep = ''
    for line in toc:
        if line != '\n' and not line.startswith('CHAPTER'):
            keep += line
    print(keep.strip())


main()
