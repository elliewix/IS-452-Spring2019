def calculate_wages(hours_workd, hourly_wage):
    if hours_workd > 40:
        return (40 * hourly_wage) + (hours_workd - 40) * hourly_wage * 1.5
    else:
        return hours_workd * hourly_wage


def main():
    worked = eval(input('Hours worked: '))
    wage = eval(input('Hourly wage: '))
    print(calculate_wages(worked, wage))


main()
