toc = """CHAPTER VII

Cutting from "The Dailygraph," 8 August                               71"""


def main():
    ### capitalize() ###
    # The capitalize() method only capitalizes the first letter of the first word in the string, so 'CHAPTER VII'
    # becomes 'Chapter vii' and all other words in the string are lower case.
    print('----capitalize()----')
    capitalized = toc.capitalize()
    print(capitalized, end='\n\n')

    ### find() ###
    # The find() method gives the index of the string at which the substring occurs. In this case, I have searched for
    # the first occurrence of a quotation mark.
    print('----find()----')
    first_quote = toc.find('"')
    print('Quotes first occur at character number', first_quote, end='\n\n')

    ### join() ###
    # To use join(), we first need a list of items to join together. We do this by splitting the TOC on the
    # double quotes. We then join these pieces back together separated by single quotes.
    print('----join()----')
    toc_bits = toc.split('"')
    single_quote_title = "'".join(toc_bits)
    print(single_quote_title, end='\n\n')

    ### replace() ###
    # In the spirit of the last example, we replace the double quotes with underscores.
    print('----replace()----')
    underscore_title = toc.replace('"', '_')
    print(underscore_title, end='\n\n')

    ### center() ###
    # We get the line containing 'CHAPTER VII' by splitting on newline characters and grabbing the first (zeroth)
    # line. We then center the line with a width of 50, meaning the 'CHAPTER VII' is surrounded on the left and right
    # with approximately equal numbers of spaces to place it in the center.
    print('----center()----')
    first_chapter = toc.split('\n')[0]
    centered_first_chapter = first_chapter.center(50)
    print(centered_first_chapter, end='\n\n')

    ### count() ###
    print('----count()----')
    number_of_quotes = toc.count('"')
    print('There are', number_of_quotes, 'quotation marks in the string', end='\n\n')

    ### ljust() ###
    # Though you can't see it, here we print the first chapter line followed by several spaces so that it is left
    # justified. We then do the same but followed by underscores for visibility.
    print('----ljust()----')
    left_justified_first_chapter = first_chapter.ljust(50)
    print(left_justified_first_chapter)
    left_justified_first_chapter_underscores = first_chapter.ljust(50, '_')
    print(left_justified_first_chapter_underscores, end='\n\n')

    ### lower() ###
    # This simply prints the TOC string in all lowercase letters.
    print('----lower()----')
    lower_case = toc.lower()
    print(lower_case, end='\n\n')

    ### lstrip() ###
    # We get the page number line and remove all text besides the page number and its preceding spaces. We then
    # lstrip() to remove the spaces and place the page number at the beginning of the line when it is printed.
    print('----lstrip()----')
    page_number_line = toc.split('\n')[2]
    page_number = page_number_line.replace('Cutting from "The Dailygraph," 8 August ', '')
    print(page_number.lstrip(), end='\n\n')

    ### rfind() ###
    # We find the string index of the last quotation mark with rfind().
    print('----rfind()----')
    last_quote = toc.rfind('"')
    print('The last quotation mark begins at character number', last_quote, end='\n\n')

    ### rjust() ###
    # We print the first chapter line preceded by several spaces so that it is right justified in a line of width 50.
    print('----rjust()----')
    right_justified_first_chapter = first_chapter.rjust(50)
    print(right_justified_first_chapter, end='\n\n')

    ### rstrip() ###
    # We will reuse our left justified 'CHAPTER VII' and remove the spaces we added before using the rstrip() method. As
    # before, we will do the same with underscores.
    print('----rstrip()----')
    rstripped_first_chapter = left_justified_first_chapter.rstrip()
    print(rstripped_first_chapter, end='\n\n')

    ### split() ###
    # We will split the text on the quotation marks, creating a list of substrings. You will see newline characters
    # ('\n') in the list wherever there is a line break.
    print('----split()----')
    split_toc = toc.split('"')
    print(split_toc, end='\n\n')

    ### title() ###
    # title() attempts to title-case the string by capitalizing the first letter of each word. Note that there are some
    # funny results, though: the letter 's' after an apostrophe is capitalized and roman numerals can look like 'Iv'
    print('----title()----')
    title_case = toc.title()
    print(title_case, end='\n\n')

    ### upper() ###
    # The opposite of lower(), upper() simply makes all letters uppercase in the string.
    print('----upper()----')
    upper_case = toc.upper()
    print(upper_case, end='\n\n')


main()


"""
Rubric - Per method - Total: 7.5pt
    Accurately described and used - 0.5pt
"""
