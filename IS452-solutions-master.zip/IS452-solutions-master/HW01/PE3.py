def main():
    celsius = eval(input("What is the Celsius temperature? "))
    fahrenheit = 9/5 * celsius + 32
    print("The temperature is", fahrenheit, "degrees Fahrenheit.")


for i in range(5):
    main()


"""
Rubric: - Total: 6pt
    Program uses a for-loop - 2pt
    Program repeats 5 times - 2pt
    Program gets user input on each loop - 1pt
    Narrative - 1pt
"""
