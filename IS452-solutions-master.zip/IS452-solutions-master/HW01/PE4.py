def main():
    print("Celsius  Fahrenheit")
    for celsius in range(0, 101, 10):
        fahrenheit = 9/5 * celsius + 32
        print(celsius, "\t", fahrenheit)

main()


"""
Rubric - Total: 4.5pt
    Program uses a for-loop - 2pt
    Program converts the correct celsius temperatures (even if Fahrenheit temperatures are incorrect) - 1.5pt
    Narrative - 1pt
"""
