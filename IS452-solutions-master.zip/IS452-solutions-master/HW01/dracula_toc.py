toc = """CHAPTER VII

Cutting from "The Dailygraph," 8 August                               71"""
