toc = """CHAPTER VII

Cutting from "The Dailygraph," 8 August                               71"""


def main():
    ### capitalize() ###
    # The capitalize() method only capitalizes the first letter of the first word in the string, so 'CHAPTER VII'
    # becomes 'Chapter vii' and all other words in the string are lower case.
    print('----capitalize()----')
    capitalized = toc.capitalize()
    print(capitalized, end='\n\n')

    ### find() ###
    # The find() method gives the index of the string at which the substring occurs. In this case, I have searched for
    # the first occurrence of a quotation mark.
    print('----find()----')
    first_quote = toc.find('"')
    print('Quotes first occur at character number', first_quote, end='\n\n')

    ### join() ###
    # To use join(), we first need a list of items to join together. We do this by splitting the TOC on the
    # double quotes. We then join these pieces back together separated by single quotes.
    print('----join()----')
    toc_bits = toc.split('"')
    single_quote_title = "'".join(toc_bits)
    print(single_quote_title, end='\n\n')

    ### replace() ###
    # In the spirit of the last example, we replace the double quotes with underscores.
    print('----replace()----')
    underscore_title = toc.replace('"', '_')
    print(underscore_title, end='\n\n')


main()


"""
Rubric - Per method - Total: 6pt
    Uses method correctly - 1pt
    Describes method correctly - 0.5pt
"""
