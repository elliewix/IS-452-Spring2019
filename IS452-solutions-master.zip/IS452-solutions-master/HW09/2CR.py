from collections import Counter


def main():
    dracula = open('dracula.txt', 'r')
    all_text = dracula.readlines()
    dracula.close()

    start_index = all_text.index('DRACULA\n')
    end_index = all_text.index('                                THE END\n')+1

    content_lines = all_text[start_index:end_index]

    # I'm using a Counter() object, which is much handier than a standard dictionary for these purposes. The answer for
    # 4CR shows an alternative approach using standard dictionaries.
    word_counts = Counter()
    for line in content_lines:
        words = line.lower().split()
        for word in words:
            word_counts[word] = word_counts.get(word, 0) + 1

    for word, freq in word_counts.most_common(100):
        print(word, freq)


main()
