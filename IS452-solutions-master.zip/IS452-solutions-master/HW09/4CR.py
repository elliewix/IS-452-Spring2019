stopwords = ['the', 'of', 'and', 'to', 'a', 'in', 'that', 'was', 'for', 'it']  # among the most common words in English


def main():
    dracula = open('dracula.txt', 'r')
    all_text = dracula.readlines()
    dracula.close()

    start_index = all_text.index('DRACULA\n')
    end_index = all_text.index('                                THE END\n')+1

    content_lines = all_text[start_index:end_index]

    # See the 2CR answer for a simpler Counter-based solution.
    word_counts = {}
    for line in content_lines:
        words = line.lower().split()
        for word in words:
            if word not in stopwords:
                word_counts[word] = word_counts.get(word, 0) + 1

    # Calling items() and casting to list results in a list of tuples, with each tuple containing the (key,
    # value). For word counts, this looks like [('happy', 3), ('nail-studded', 1), ('lucy', 141), ...]. A dictionary
    # isn't directly sortable, but turning into a list in this way makes the elements sortable.
    word_count_tuples = list(word_counts.items())

    # sort() will call the byFreq() method once for each element in the list that's being sorted. In this case,
    # each element is an individual tuple (see above). The value returned by byFreq() will be the basis of the sorting,
    # so we want to make sure we return the count.
    word_count_tuples.sort(key=byFreq, reverse=True)
    for word, freq in word_count_tuples[:100]:  # limit to the top 100 after sorting
        print(word, freq)


# As mentioned above, the value returned by byFreq() will the basis of the sorting. Since we want the list to be
# sorted on the basis of the word counts, and since the word count is at index 1 of each (word, count) tuple,
# we return the value at index 1.
def byFreq(pair):
    return pair[1]


main()
