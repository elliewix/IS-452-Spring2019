def main():
    n = eval(input("How many numbers will you input? "))

    total = 0
    for i in range(n):
        number = eval(input("Input a number: "))
        total = total + number

    average = total / n
    print(average)


main()


"""
Rubric - Total: 4pt
    Program gets user input twice - 1pt
    Program computes the average - 1pt
    Program uses float division - 1pt
    Narrative - 1pt
"""
