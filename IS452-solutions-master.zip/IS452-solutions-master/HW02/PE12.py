def main():
    n = eval(input("How many natural numbers? "))

    total = 0
    for number in range(1, n+1):
        cubed = number**3
        total = total + cubed

    print(total)


main()


"""
Rubric - Total: 3pt
    Program uses exponentiation operator - 1pt
    Program aggregates within the for loop - 1pt
    Narrative - 1pt
"""
