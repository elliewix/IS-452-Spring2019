# The for-loop is iterating over integers from 1 to 10 (since 11 is exclusive) and printing each integer's square.
#
# Rubric:
## Correct range - 1pt
## Mentions multiplication (or squaring) - 1pt
def a():
    for i in range(1, 11):
        print(i*i)


# The for-loop is iterating over each of the odd numbers in the list (1-9) and printing the number, followed by a colon,
# followed by the cube of the number. After the loop completes, the number 9 is printed because it was the last value
# that i was set to.
#
# Rubric:
## Acknowledge the exponentiation/cubing - 1pt
## State that i == 9 after the loop - 1pt
def b():
    for i in [1, 3, 5, 7, 9]:
        print(i, ":", i**3)
    print(i)


# First, x is assigned the value of 2 and y is assigned the value of 10. The code then begins looping from 0 to 8 by
# even numbers because the step is set to x=2. Each even number is printed followed without space by the number 12.
# Notice that 12 does not change because the values of x and y are constant -- it is the value of j that changes with
# each iteration of the loop. Finally, after exiting the loop, we see the word "done" on its own line.
#
# Rubric:
## Accurately explains the loop (0 to 8, evens only/every other, explains end="") - 1pt
## Does not assume x and y update on each iteration - 1pt
def c():
    x = 2
    y = 10
    for j in range(0, y, x):
        print(j, end="")
        print(x + y)
    print("done")


# The variable ans is set to 0. We enter a loop from 1 to 10, each time increasing i by 1. In each iteration of the
# loop, we set ans equal to its previous value plus the current value of i squared. For example, on the first iteration
# of the loop, i == 1, so ans == 0 + 1 * 1 == 1. On the second iteration, i == 2, so ans == 1 + 2 * 2 == 5. Notice that
# ans is still set to 1 on the second iteration of the loop. We print out the value of i on each iteration, which is
# simply 1, 2, 3, ..., 10. At the end of the loop, we print out ans, which has reached the value of 385.
#
# Rubric:
## Notice that ans is updated continually, not set back to 0 on each loop iteration - 1pt
## Accurately describe the output (print only the range variables, print ans only at the end) - 1pt
def d():
    ans = 0
    for i in range(1, 11):
        ans = ans + i*i
        print(i)
    print (ans)

"""
Rubric - Total: 8pt
"""
