def main():
    n = eval(input("How many natural numbers? "))

    total = 0
    for number in range(1, n+1):
        total = total + number

    print(total)


main()


"""
Rubric - Total: 2pt
    Program correctly sums the first n natural numbers - 1pt
    Narrative - 1pt
"""
