def main():
    n = eval(input("How many numbers will you input? "))

    total = 0
    for i in range(n):
        number = eval(input("Input a number: "))
        total = total + number

    print(total)


main()


"""
Rubric - Total: 3pt
    Program gets user input twice - 1pt
    Program sums the user's numbers - 1pt
    Narrative - 1pt
"""
