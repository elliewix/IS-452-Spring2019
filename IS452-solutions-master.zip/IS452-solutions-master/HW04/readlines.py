def main():
    in_file = open('dracula.txt', 'r')
    text_lines = in_file.readlines()
    in_file.close()

    toc_start = text_lines.index('CONTENTS\n')  # include the \n because index requires an exact match
    toc_end = text_lines.index('DRACULA\n')

    toc_list = text_lines[toc_start:toc_end]

    print(''.join(toc_list))  # join separated by an empty string since the string already contains newlines


main()
