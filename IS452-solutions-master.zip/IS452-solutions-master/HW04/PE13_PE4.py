def main():
    in_file = open('full_names.txt', 'r')  # this file has one phrase per line to be acronymized
    out_file = open('acronym_names.txt', 'w')

    for phrase in in_file.readlines():
        words = phrase.split()  # split phrase on white space to create a list of words

        first_letters = ''
        for word in words:
            first_letters = first_letters + word[0]  # add the first letter of each word

        print(first_letters.upper(), file=out_file)

    in_file.close()
    out_file.close()


main()
