def main():
    in_file = open('quotes.txt', 'r')  # assume this file has one quote per line to be counted
    out_file = open('quote_lengths.txt', 'w')

    for quote in in_file.readlines():
        quote = quote.strip()  # remove any extra spaces or new lines hanging at the end of the sentence
        words = quote.split()
        print(len(words), file=out_file)

    in_file.close()
    out_file.close()


main()
