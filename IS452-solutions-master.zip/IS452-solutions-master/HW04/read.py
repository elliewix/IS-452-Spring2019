def main():
    in_file = open('dracula.txt', 'r')
    text = in_file.read()
    in_file.close()

    toc_start = text.find('CONTENTS')
    toc_end = text.find('DRACULA', toc_start)  # find the first instance of 'DRACULA', starting from the beginning of the TOC

    toc = text[toc_start:toc_end]  # slice out the text between the start and end of the TOC

    print(toc)


main()
