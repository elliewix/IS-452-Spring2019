def main():
    in_file = open('dracula.txt', 'r')

    toc_end = 184  # the number of the last line of the TOC

    text_lines = []
    for i in range(toc_end+1):  # add 1 so the last line is included
        line = in_file.readline()
        text_lines.append(line)

    toc_start = text_lines.index('CONTENTS\n')  # include the \n because index requires an exact match

    # we have all lines up to the end of the TOC, so now grab only the lines from the TOC start to the end of the list
    toc_list = text_lines[toc_start:]

    print(''.join(toc_list))  # join separated by an empty string since the string already contains newlines

    in_file.close()


main()
