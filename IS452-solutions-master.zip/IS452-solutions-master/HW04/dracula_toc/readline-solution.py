def main():
    toc = open('dracula_toc.txt')

    chapter = 1
    for line in toc:
        output = open('Chapter-'+str(chapter)+'.txt', 'w')

        output.write(line)
        output.write(toc.readline())
        output.write(toc.readline())
        output.write(toc.readline())

        chapter += 1


main()
