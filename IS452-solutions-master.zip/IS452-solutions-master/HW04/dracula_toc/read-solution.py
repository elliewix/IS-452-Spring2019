def main():
    toc = open('dracula_toc.txt')
    toc_string = toc.read()
    toc_lines = toc_string.split('\n')  # the only difference between this and the readlines() solution!

    chapter = 1

    # We'll iterate over every fourth line, which is the start of the next chapter
    for i in range(0, len(toc_lines), 4):
        output = open('Chapter-'+str(chapter)+'.txt', 'w')

        # The current chapter is from i to i+4, because it contains four lines (including the final blank line)
        this_chapter = toc_lines[i:i+4]

        # We write each line of the chapter to the output file
        for line in this_chapter:  # alternatively, output.write("".join(this_chapter))
            output.write(line)

        # Now update the chapter number before the next loop begins
        chapter += 1


main()
