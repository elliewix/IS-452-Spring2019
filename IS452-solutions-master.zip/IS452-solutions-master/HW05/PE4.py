def sumN(n):
    total = 0
    for number in range(1, n+1):
        total = total + number
    return total


def sumNCubes(n):
    total = 0
    for number in range(1, n+1):
        cubed = number**3
        total = total + cubed
    return total


def main():
    n_input = eval(input("How many natural numbers? "))

    sum_of_nums = sumN(n_input)
    sum_of_cubed_nums = sumNCubes(n_input)

    print('Sum of the first', n_input, 'natural numbers:', sum_of_nums)
    print('Sum of the cubes of the first', n_input, 'natural numbers:', sum_of_cubed_nums)


main()
