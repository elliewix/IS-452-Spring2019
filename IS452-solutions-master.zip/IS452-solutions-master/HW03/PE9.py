def main():
    sentence = input('Give me a sentence: ')
    words = sentence.split()
    print(len(words))


main()
