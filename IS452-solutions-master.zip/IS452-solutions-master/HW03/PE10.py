def main():
    sentence = input('Give me a sentence: ')
    words = sentence.split()

    total = 0
    for word in words:
        total += len(word)
    average = total / len(words)

    print(average)


main()
