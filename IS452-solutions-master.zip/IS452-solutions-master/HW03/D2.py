s1 = 'spam'
s2 = 'ni!'


def a():
    print(s2.upper()[:-1])


def b():
    print(s2 + s1 + s2)


def c():
    spam_ni = s1 + ' ' + s2
    spam_ni = spam_ni.title()
    print('  '.join([spam_ni, spam_ni, spam_ni]))


def d():
    print(s1.strip())


def e():
    print(s1.split('a'))


def f():
    print(s1.replace('a', ''))
