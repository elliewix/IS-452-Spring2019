# We loop over each character in the string 'aardvark' and print out that character, so that we have a series of lines,
# each containing a single character from 'aardvark' in order.
def a():
    for ch in 'aardvark':
        print(ch)


# First, we split the sentence based on white space, creating a list of words (the last word is "discontent..."
# including the ellipsis). Then, we iterate over each word and print it, so that we have a series of lines, each
# containing a single word from the sentence in order.
def b():
    for w in 'Now is the winter of our discontent...'.split():
        print(w)


# First, we split the string 'Mississippi' on the character 'i' so that we have a list of substrings that looks like:
# ['M', 'ss', 'ss', 'pp', '']. We print each of those substrings followed by a space, so that in the end we are left with
# 'M ss ss pp ' in one line.
def c():
    for w in 'Mississippi'.split('i'):
        print(w, end=' ')


# We initialize msg as an empty string. We then split the string 'secret' on the character 'e' to get a list of
# substrings ['s', 'cr', 't']. We iterate over each of these substrings and add them to msg, so that in the end
# we output a message of 'scrt'.
def d():
    msg = ''
    for s in 'secret'.split('e'):
        msg = msg + s
    print(msg)


# We initialize msg as an empty string. We then iterate over each character in 'secret' and accumulate a new msg
# composed of the character after the character we're looking at in 'secret'. So, we get the numerical equivalent of the
# character with ord(ch). We add 1, so that we have the numerical equivalent of the *next* character. Then we translate
# this number back into a character with chr() and add this to the end of msg. We get back a string with the letters in
# 'secret' shifted to the next character (the next letter in the alphabet).
def e():
    msg = ''
    for ch in 'secret':
        msg = msg + chr(ord(ch)+1)
    print(msg)
