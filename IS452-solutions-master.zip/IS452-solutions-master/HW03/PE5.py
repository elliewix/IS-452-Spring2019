def main():
    offset = ord('a') - 1  # the amount by which the value of ord() overshoots the position in the alphabet

    name = input('Whats your name? ')
    name = name.lower()  # makes the name all lowercase since capitals have a different offset

    total = 0
    for letter in name:
        letter_number = ord(letter) - offset
        total += letter_number

    print(total)


main()
