-- Rads are a deprecated unit of measurement. The preferred measure is the Gray (Gy) where 1 rad = 0.01 Gy. Convert the
-- survey rads to Grays, since that is preferred, and show the location and date of the measurement so we know what the
-- value actually represents.

SELECT site, dated, reading / 100 AS Gys FROM Survey JOIN Visited ON Survey.taken = Visited.id WHERE quant = 'rad';


-- State which site was visited on which day, and show the location of the site.

SELECT 'Visited ' || site || ' at ' || lat || ',' || long || ' on ' || dated FROM Visited JOIN Site ON Visited.site = Site.name WHERE dated IS NOT NULL;


-- We want to know who took which samples and the date of the sample.

SELECT personal, family, site, dated, quant, reading FROM Person JOIN Visited JOIN Survey ON Person.id = Survey.person AND Survey.taken = Visited.id;


-- Do certain crew members seem to get higher measurements than others?

SELECT family, quant, AVG(reading) AS average_reading FROM Survey JOIN Person ON Survey.person = Person.id GROUP BY person, quant;
